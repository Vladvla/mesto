import { Popup } from "./Popup.js";

export class PopupWithDeleteCard extends Popup {
  constructor({ popup, handleFormSubmit }) {
    super(popup);
		this._handleFormsubmit = handleFormsubmit;
		this._popupForm = this._popup.querySelector('.popup__edit-form');
		this._buttonSubmit = this._popup.querySelector('.popup__button');
  }

  open(cardId, handlerDeleteCard) { //  передаем айди карточки, и функцию удаления карточки
    super.open();
    this.handlerDeleteCard = handlerDeleteCard;
    this._id = cardId;
  }

  id() {
    return this._id;
  }

  setEventListeners() {
    super.setEventListeners()
    this._popup.addEventListener('submit', (e) => {
      e.preventDefault();
      this._handleFormSubmit(); //  отправляем на сервер
    });
  }
}